/**
 * @author Daniel
 * @date 2020-02-09
 *
 * Class created in class algorithm and data structure at Uppsala university.
 * Creates a single linked list with para meter E
 * @param <E>
 */
public class SingleLinkedList<E> implements ISingleLinkedList<E> {
    Node<E> head;
    Node<E> tail;
    int size;

    /**
     * Default constructor
     */
    public SingleLinkedList(){head = null;tail = null;size = 0;}

    /**
     * Adds an element to the list
     * Fixes head and tail pointers.
     * @param element element to be appended to the end of this list
     */
    @Override
    public void add(E element) {
       Node newTail = new Node(element);

       //If it exists any item in the list, change next pointer on oldtail to newTail.
        if(tail != null)
            tail.setmNextNode(newTail);
        //List is empty, tail, head points to the new element.
        else{
            tail = newTail;
            head = newTail;
        }

        tail = newTail;
        size++;
    }

    /**
     * Adds an element to a specific index in the list.
     * Depending on how big the list is, and where to put the new element it some diffrent
     * cases that can arise.
     * 1: list is empty and add on index 0, we reuse code from add(element) method.
     * 2.1: Add on index 0 on a nonempty-list. Changes header pointer to new element.
     * 2.2: Add on last index on a nonempty-list. Changes tailer pointer to new element.
     * 2.3: Add on an index between head and tail-pointer.
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException
     */
    @Override
    public void add(int index, E element) throws IndexOutOfBoundsException {
        if (index > this.size || index < 0)
            throw new IndexOutOfBoundsException("Index is out of bound");

        if(this.size == 0)
            add(element);
        else{

            Node newNode = new Node(element);

            //Add on head spot
            if(index == 0){
                Node oldHead = head;
                this.head = newNode;
                head.setmNextNode(oldHead);
            }
            //Add on tail spot
            else if(index == this.size){
                Node newTail = newNode;
                tail.setmNextNode(newTail);
                tail = newTail;
            }
            //Add between head and tail
            else {
                Node before = getNode(index-1);
                newNode.setmNextNode(before.getmNextNode());
                before.setmNextNode(newNode);
            }
            this.size++;
        }
    }

    /**
     * Clear whole list by settting
     * head pointer to new node
     * tail pointer to head
     */
    @Override
    public void clear() {
        head = new Node();
        tail = head;
        size = 0;
    }

    /**
     * Returns a specific element from index
     * @param index index of the element to return
     * @return element on specific index
     * @throws IndexOutOfBoundsException
     */
    @Override
    public E get(int index) throws IndexOutOfBoundsException {
        if (index >= this.size())
            throw new IndexOutOfBoundsException("Index is out of bound: " + index);

        Node current = getNode(index);
        return (E) current.getmElement();
    }

    /**
     *
     * @param element element to search for
     * @return
     */
    @Override
    public int indexOf(E element) {
        Node current = head;
        for(int i = 0; i < this.size; i++){
            if(current.getmElement().equals(element))
                return i;
            else
                current = current.getmNextNode();
        }
        return -1;
    }

    /**
     * Removes a specific element from list
     * @param index the index of the element to be removed
     * @return element that was removed
     * @throws IndexOutOfBoundsException
     */
    @Override
    public E remove(int index) throws IndexOutOfBoundsException {
        if (index >= this.size() || index < 0) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bound");
        }
        E elementToBeRemoved = get(index);

        //Fix head pointer
        if(index == 0){
            head = head.getmNextNode();
        }
        //fix tail ponter
        else if(index == this.size){
            Node temp = head;
            for(int i = 0; i < this.size; i++){
                if(temp.getmNextNode().equals(this.tail)){
                    tail = temp;
                }
            }
        }
        //fix pointers between head and tail
        else{
            Node beforeRemove = getNode((index-1));
            beforeRemove.setmNextNode(beforeRemove.getmNextNode().getmNextNode());
        }

        size--;
        return elementToBeRemoved;
    }

    /**
     * Updates a specific element with new data
     * @param index index of the element to replace
     * @param element element to be stored at the specified index
     * @return old element
     * @throws IndexOutOfBoundsException
     */
    @Override
    public E set(int index, E element) throws IndexOutOfBoundsException {
        if ( (isEmpty() && index != 0) || index < 0 || index >= size){
            throw new IndexOutOfBoundsException();
        }

        Node node = getNode(index);
        E tmp = (E)node.getmElement();
        node.setmElement(element);
        return tmp;
    }

    @Override
    public int size() {
        return this.size;
    }

    /**
     * Converts list to array
     * @return array with all elements
     */
    @Override
    public E[] toArray() {
        if (isEmpty()) {
            return null;
        }
        E[] array = (E[]) new Object[this.size];

        Node current = head;

        for (int i = 0; i < size; i++) {
            array[i] = (E) current.getmElement();
            current = current.getmNextNode();
        }
        return array;
    }

    /**
     * Override toString and return
     * [element1.Tostring()], [element1.Tostring()], .... [elementN.Tostring()]
     * @return
     */
    @Override
    public String toString(){
        if(isEmpty() == true)
            return "[]";

        Node current = head;
        String output = "[";

        for(int i = 0; i < (this.size - 1); i++){
            output = output.concat(current.getmElement().toString());
            output = output.concat(", ");
            current = current.getmNextNode();
        }

        //adds last element
        output = output.concat(current.getmElement().toString());
        output = output.concat("]");
        return output;
    }


    /**
     * Method that returns status on list
     * if it is empty or not.
     * @return
     */
    public boolean isEmpty(){
        if(size <= 0)
            return true;
        else
            return false;
    }

    /**
     * Helper method that returns a specific element on index
     * @param index that element exists on
     * @return element if it finds any
     */
    private Node getNode(int index){
        if (index < 0 || index > size){
            throw new IndexOutOfBoundsException("Index is out of bound: " + index );
        }

        Node current = this.head;
        for(int i = 0; i < index; i++){
            current = current.getmNextNode();
        }
        return current;
    }
}

