/**
 * @author Daniel
 * @Date 2020-02-09
 *
 * Class that represent a Queue it extends DoubleLinkedList and implements IQueue.
 * @param <E>
 */
public class Queue<E> extends DoubleLinkedList<E> implements IQueue<E>{
    @Override
    public void offer(E element) {
        add(size, element);
    }

    /**
     * Returns first Element in queue without removing it from queue.
     * @return first element in queue
     */
    @Override
    public E peek() {
        if(isEmpty())
            return null;

        return (E) head.getmElement();
    }

    /**
     * Removes first element from queue and returns it.
     * @return first element from queue
     */
    @Override
    public E poll() {
        if(isEmpty())
            return null;
        Node element = (Node) remove(0);

        return (E) element.getmElement();
    }
}
