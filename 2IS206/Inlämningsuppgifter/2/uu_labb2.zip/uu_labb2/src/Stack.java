/**
 * @author Daniel
 * @date 2020-02-09
 * Class that represents a stack
 * @param <E>
 */
public class Stack<E> extends SingleLinkedList<E> implements IStack<E> {

    /**
     * Pops an item from the stack
     * @return specific element from the stack
     */
    @Override
    public E pop() {
        if(isEmpty())
            return null;

        E temp = head.getmElement();
        head = head.getmNextNode();;
        size--;

        return temp;
    }

    /**
     * Pushes an element to the stack
     * @param element element to be pushed onto this stack
     */
    @Override
    public void push(Object element) {
        Node oldFirst = head;
        head = new Node(element);

        //Stack is empty
        if(isEmpty())
            tail = head;
        //All other cases
        else
            head.setmNextNode(oldFirst);

        size++;
    }

    /**
     * Search for a specific element
     * @param element element to search for
     * @return
     */
    @Override
    public int search(E element) {
        return indexOf(element);
    }

    /**
     * Retruns top element
     * @return element at the top
     */
    @Override
    public E top() {
        if(isEmpty())
            return null;
        return head.getmElement();
    }
}
