/**
 * @author Daniel
 * @date 2020-02-09
 *
 * Class that represent a Node
 * @param <E>
 */
public class Node<E> {
    private E mElement;
    private Node<E> mNextNode;

    Node(E data){
        this.setmElement(data);
    }

    public Node() {
        mElement = null;
        mNextNode = null;
    }

    public E getmElement() {
        return this.mElement;
    }

    public void setmElement(E element){
        this.mElement = element;
    }

    public Node<E> getmNextNode(){
        return this.mNextNode;
    }

    public void setmNextNode(Node<E> node){
        this.mNextNode = node;
    }
}