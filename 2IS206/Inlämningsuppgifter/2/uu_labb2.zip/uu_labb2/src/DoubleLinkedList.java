/**
 * @author Daniel
 * @date 2020-02-09
 *
 * Class that represents a double linked list.
 * @param <E>
 */
public class DoubleLinkedList<E> implements IDoubleLinkedList {
    Node head;
    Node tail;
    int size = 0;

    /**
     * Default constructor
     */
    public DoubleLinkedList(){
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Adds an element in the end of the list.
     * @param element element to be appended to the end of this list
     */
    @Override
    public void add(Object element) {
        Node newNode = new Node(element);

        //List is empty
        if(head == null){
            this.head = newNode;
            newNode.setmPrevNode(newNode);
            newNode.setmNextNode(newNode);
        }
        //List contains at least one element
        else{
            tail.setmNextNode(newNode);
            newNode.setmNextNode(null);
            newNode.setmPrevNode(tail);
        }

        tail = newNode;
        size++;

    }

    /**
     * Adds and element to a specific index
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException
     */
    @Override
    public void add(int index, Object element) throws IndexOutOfBoundsException {
        if(index > size || index < 0)
            throw  new IndexOutOfBoundsException();

        Node newNode = new Node(element);

        //Empty list
        if(size == 0){
            head = newNode;
            tail = newNode;
        }

        //One element in list
        else if(size == 1){
            //Before the only element in list
            if(index == 0){
                newNode.setmNextNode(head);
                head.setmPrevNode(newNode);
                head = newNode;
            }
            //After the only element in list
            else{
                newNode.setmPrevNode(head);
                head.setmNextNode(newNode);
                tail = newNode;
            }
        }

        //List contains > 1 element
        else{
            //Add to index 0
            if(index == 0){
                newNode.setmNextNode(head);
                head.setmPrevNode(newNode);
                head = newNode;
            }

            //Add after last element
            else if (index == size){
                tail.setmNextNode(newNode);
                newNode.setmPrevNode(tail);
                tail = newNode;
            }

            //Add between head and tail
            else{
                Node nodeBefore = getNode(index-1);
                Node nodeAfter = nodeBefore.getmNextNode();

                nodeBefore.setmNextNode(newNode);
                newNode.setmPrevNode(nodeBefore);

                nodeAfter.setmPrevNode(newNode);
                newNode.setmNextNode(nodeAfter);
            }
        }


        size++;
    }

    /**
     * Clears the list.
     * Sets all pointers to null
     */
    @Override
    public void clear() {
        head = null;
        tail = head;
        size = 0;
    }

    /**
     *
     * @param index index of the element to return
     * @return
     * @throws IndexOutOfBoundsException
     */
    @Override
    public Object get(int index) throws IndexOutOfBoundsException {
        if(index > size || index < 0)
            throw  new IndexOutOfBoundsException();

        Node temp = head;
        for(int i = 0; i < size; i++){
            if(i == index)
                return temp.getmElement();
            temp = temp.getmNextNode();
        }
        return null;
    }

    /**
     * Find index of a specific element
     * @param element element to search for
     * @return index of an element
     */
    public int indexOf(Object element) {
        Node temp = head;
        for(int i = 0; i < size; i++) {
            if (temp.getmElement().equals(element))
                return i;
            temp = temp.getmNextNode();
        }
        return -1;
    }

    /**
     * Returns index on an element from tail position
     * @param element element to search for
     * @return
     */
    @Override
    public int lastIndexOf(Object element) {
        if (isEmpty())
            return -1;

        Node temp = tail;
        for (int i = (size-1); i >= 0; i--){

            //Found index
            if (temp.mElement.equals(element))
                return i;
            //Keep looking
            if (temp.getmPrevNode() != null){
                temp = temp.mPrevNode;
            }
        }
        //Didnt find any index
        return -1;
    }

    /**
     * Removes a specific element from list
     * @param index the index of the element to be removed
     * @return element that was removed
     * @throws IndexOutOfBoundsException
     */
    @Override
    public Object remove(int index) throws IndexOutOfBoundsException {
        if(index >= size || index < 0)
            throw new IndexOutOfBoundsException();

        Node nodeToRemove =  getNode(index);
        //Remove head
        if(index == 0){
            if(head.getmNextNode() != null) {
                head = head.getmNextNode();
                head.setmPrevNode(null);
            }
            else{
                head = null;
                tail = null;
            }
        }

        //Remove tail
        else if(index == (size - 1)){
            if(tail.getmPrevNode() != null){
                tail = tail.getmPrevNode();
                tail.setmNextNode(null);
            }
        }

        //Remove between head and tail
        else{
            Node nodeBefore = nodeToRemove.getmPrevNode();
            Node nodeAfter = nodeToRemove.getmNextNode();

            nodeBefore.setmNextNode(nodeAfter);;
            nodeAfter.setmPrevNode(nodeBefore);
        }
        size--;

        return nodeToRemove;
    }

    /**
     * Updates a specific element with new data
     * @param index index of the element to replace
     * @param element element to be stored at the specified index
     * @return old element
     * @throws IndexOutOfBoundsException
     */
    @Override
    public Object set(int index, Object element) throws IndexOutOfBoundsException {
        if ( (isEmpty() && index != 0) ||  index >= size || index < 0)
            throw  new IndexOutOfBoundsException();

        Node newNode = getNode(index);

        newNode.setmElement(element);
        return newNode;
    }

    @Override
    public int size() {
        return size;
    }

    /**
     * Converts linked list to array
     * @return array with all elements
     */
    @Override
    public E[] toArray() {
        if (isEmpty()) {
            return null;
        }
        E[] array = (E[]) new Object[size];

        Node current = head;

        for (int i = 0; i < size; i++) {
            array[i] = (E) current.getmElement();
            current = current.getmNextNode();
        }
        return array;
    }

    /**
     * Override toString and return
     * [element1.Tostring()], [element1.Tostring()], .... [elementN.Tostring()]
     * @return
     */
    @Override
    public String toString(){
        if(isEmpty() == true)
            return "[]";
        StringBuilder output = new StringBuilder();
        Node temp = head;
        output.append("[");

        for(int i = 0; i < this.size; i++){
            if((this.size - i) > 1)
                output.append(temp.getmElement() + ", ");
            else
                output.append(temp.getmElement() + "]");

            temp = temp.mNextNode;
        }

        return output.toString();
    }

    /**
     * Check if stack is empty or not
     * @return status if the stack is empty or not
     */
    boolean isEmpty(){
        return head == null;
    }

    /**
     * Helper method that returns a specific element on index
     * @param index that element exists on
     * @return element if it finds any
     */
    private Node getNode(int index){
        if (index < 0 || index > size){
            throw new IndexOutOfBoundsException("Index is out of bound: " + index );
        }

        Node current = this.head;
        for(int i = 0; i < index; i++){
            current = current.getmNextNode();
        }
        return current;
    }


    /**
     * Private class that represents a node with double links.
     * @param <E>
     */
    protected  class Node<E>{
        protected E mElement;
        protected Node<E> mNextNode;
        protected Node<E> mPrevNode;

        protected  Node(E element) {
            this.mElement = element;
        }

        protected  E getmElement() {
            return mElement;
        }

        protected  void setmElement(E mElement) {
            this.mElement = mElement;
        }

        protected  Node<E> getmNextNode() {
            return mNextNode;
        }

        protected  void setmNextNode(Node<E> mNextNode) {
            this.mNextNode = mNextNode;
        }

        protected  Node<E> getmPrevNode() {
            return mPrevNode;
        }

        protected void setmPrevNode(Node<E> mPrevNode) {
            this.mPrevNode = mPrevNode;
        }




    }
}
